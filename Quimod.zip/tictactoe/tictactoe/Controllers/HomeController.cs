using Microsoft.AspNetCore.Mvc;

namespace tictactoe.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View(); // Main Menu
        }

        public IActionResult SinglePlayer()
        {
            return View(); // AI vs Human
        }

        public IActionResult MultiPlayer()
        {
            return View(); // Local Multiplayer
        }

        public IActionResult Pvp()
        {
            return View(); // Real-time PvP with SignalR
        }
    }
}
