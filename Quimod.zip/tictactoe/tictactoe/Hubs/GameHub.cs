﻿namespace tictactoe.Hubs
{
    using Microsoft.AspNetCore.SignalR;
    using System.Collections.Concurrent;

    public class GameHub : Hub
    {
        private static ConcurrentDictionary<string, GameSession> games = new();

        public async Task JoinGame(string gameId)
        {
            if (!games.ContainsKey(gameId))
            {
                games[gameId] = new GameSession();
            }

            var game = games[gameId];

            if (game.PlayerX == null)
            {
                game.PlayerX = Context.ConnectionId;
                await Clients.Caller.SendAsync("PlayerAssigned", "X");
            }
            else if (game.PlayerO == null)
            {
                game.PlayerO = Context.ConnectionId;
                await Clients.Caller.SendAsync("PlayerAssigned", "O");
            }

            await Groups.AddToGroupAsync(Context.ConnectionId, gameId);
            await Clients.Group(gameId).SendAsync("UpdateTurn", game.CurrentTurn);
        }

        public async Task MakeMove(string gameId, int cellIndex, string player)
        {
            if (!games.ContainsKey(gameId)) return;

            var game = games[gameId];

            if (game.CurrentTurn != player || game.Board[cellIndex] != "") return;

            game.Board[cellIndex] = player;
            game.CurrentTurn = (player == "X") ? "O" : "X";

            await Clients.Group(gameId).SendAsync("ReceiveMove", cellIndex, player);
            await Clients.Group(gameId).SendAsync("UpdateTurn", game.CurrentTurn);

            string winner = CheckWinner(game.Board);
            if (winner != null)
            {
                if (winner == "X") game.XWins++;
                else if (winner == "O") game.OWins++;
                else if (winner == "Draw") game.Draws++;

                await Clients.Group(gameId).SendAsync("GameOver", winner, game.XWins, game.OWins, game.Draws);
                game.ResetBoard();
            }
        }

        public async Task RequestRematch(string gameId)
        {
            if (!games.ContainsKey(gameId)) return;

            var game = games[gameId];

            if (game.WaitingForRematch)
            {
                game.ResetBoard();
                game.WaitingForRematch = false;
                await Clients.Group(gameId).SendAsync("RematchAccepted");
            }
            else
            {
                game.WaitingForRematch = true;
                await Clients.Caller.SendAsync("WaitingForOpponent"); // Notify the first player
            }
        }


        public async Task PlayerLeft(string gameId)
        {
            if (games.ContainsKey(gameId))
            {
                await Clients.Group(gameId).SendAsync("OpponentLeft");
                games.Remove(gameId, out _);
            }
        }

        private string? CheckWinner(string[] board)
        {
            int[][] winningCombos = {
                new [] {0, 1, 2}, new [] {3, 4, 5}, new [] {6, 7, 8},
                new [] {0, 3, 6}, new [] {1, 4, 7}, new [] {2, 5, 8},
                new [] {0, 4, 8}, new [] {2, 4, 6}
            };

            foreach (var combo in winningCombos)
            {
                if (!string.IsNullOrEmpty(board[combo[0]]) &&
                    board[combo[0]] == board[combo[1]] &&
                    board[combo[1]] == board[combo[2]])
                {
                    return board[combo[0]];
                }
            }

            return board.All(cell => !string.IsNullOrEmpty(cell)) ? "Draw" : null;
        }
    }

    public class GameSession
    {
        public string? PlayerX { get; set; }
        public string? PlayerO { get; set; }
        public string CurrentTurn { get; set; } = "X";
        public string[] Board { get; set; } = new string[9] { "", "", "", "", "", "", "", "", "" };

        // Scoreboard fields
        public int XWins { get; set; } = 0;
        public int OWins { get; set; } = 0;
        public int Draws { get; set; } = 0;

        public bool WaitingForRematch { get; set; } = false; // Track if one player has requested rematch

        public void ResetBoard()
        {
            Board = new string[9] { "", "", "", "", "", "", "", "", "" };
            CurrentTurn = "X";
        }
    }
}
